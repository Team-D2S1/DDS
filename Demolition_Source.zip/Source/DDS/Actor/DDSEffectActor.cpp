// Copyright © Team DDS 2025. Project DDS™ is a trademark of Team DDS. All Rights Reserved.


#include "DDSEffectActor.h"

#include "AbilitySystemComponent.h"
#include "AbilitySystemInterface.h"
#include "Components/SphereComponent.h"
#include "DDS/GameAbilitySystem/DDSAttributeSet.h"

// Sets default values
ADDSEffectActor::ADDSEffectActor()
{
 	// 틱 비활성화
	PrimaryActorTick.bCanEverTick = false;

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	SetRootComponent(Mesh);
	
	Sphere = CreateDefaultSubobject<USphereComponent>(TEXT("Sphere"));
	Sphere->SetupAttachment(GetRootComponent());
	
}

void ADDSEffectActor::OnOverlapBegin(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	//TODO : Gameplay Effect 적용, 테스트용 코드
	IAbilitySystemInterface* AbilitySystemInterface = Cast<IAbilitySystemInterface>(OtherActor);
	if (AbilitySystemInterface)
	{
		const UDDSAttributeSet* DDSAttributeSet =Cast<UDDSAttributeSet>(AbilitySystemInterface->GetAbilitySystemComponent()->GetAttributeSet(UDDSAttributeSet::StaticClass()));

		// 이거 하면 안됨!
		if (UDDSAttributeSet* mutableDDSAttributeSet = const_cast<UDDSAttributeSet*>(DDSAttributeSet))
		{
			mutableDDSAttributeSet->SetHealth(mutableDDSAttributeSet->GetHealth() + 25.f);
			Destroy();
		}
	}
}

void ADDSEffectActor::OnOverlapEnd(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	
}

// Called when the game starts or when spawned
void ADDSEffectActor::BeginPlay()
{
	Super::BeginPlay();
	Sphere->OnComponentBeginOverlap.AddDynamic(this, &ADDSEffectActor::OnOverlapBegin);
	Sphere->OnComponentEndOverlap.AddDynamic(this, &ADDSEffectActor::OnOverlapEnd);
}