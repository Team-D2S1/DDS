// Copyright © Team DDS 2025. Project DDS™ is a trademark of Team DDS. All Rights Reserved.


#include "Components/Inventory/InventoryComponentInterface.h"


// Add default functionality here for any IInventoryComponentInterface functions that are not pure virtual.
