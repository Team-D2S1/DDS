// Copyright © Team DDS 2025. Project DDS™ is a trademark of Team DDS. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "PlayerController/InGamePlayerController.h"
#include "PawnExtensionComponentBase.generated.h"



UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class DDS_API UPawnExtensionComponentBase : public UActorComponent
{
	GENERATED_BODY()
protected:

	/**
	 * 폰의 파생 클래스를 얻는 함수
	 */
	template<class T>
	T* GetOwningPawn() const
	{
		static_assert(TPointerIsConvertibleFromTo<T,APawn>::Value,"'T' template parameter to GetOwningPawn must be derived from APawn");
		return CastChecked<T>(GetOwner());
	}

	/**
	 * 폰의 파생 클래스를 얻는 함수
	 */
	APawn* GetOwningPawn() const
	{
		return GetOwningPawn<APawn>();
	}

	/**
	 * 플레이어 컨트롤러의 파생 클래스를 얻는 함수
	 */
	template<class T>
	T* GetOwningPlayerController() const
	{
		static_assert(TPointerIsConvertibleFromTo<T,APlayerController>::Value,"'T' template parameter to GetOwningPlayerController must be derived from APlayerController");
		return CastChecked<T>(GetOwner());
	}

	AInGamePlayerController* GetOwningPlayerController() const
	{
		return GetOwningPlayerController<AInGamePlayerController>();
	}
};