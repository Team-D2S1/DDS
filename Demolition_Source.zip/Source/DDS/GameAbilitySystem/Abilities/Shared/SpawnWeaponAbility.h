// Copyright © Team DDS 2025. Project DDS™ is a trademark of Team DDS. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameAbilitySystem/Abilities/DDSGameplayAbility.h"
#include "SpawnWeaponAbility.generated.h"

/**
 * 
 */
UCLASS()
class DDS_API USpawnWeaponAbility : public UDDSGameplayAbility
{
	GENERATED_BODY()
public:

	virtual void ActivateAbility(const FGameplayAbilitySpecHandle Handle, const FGameplayAbilityActorInfo* ActorInfo, const FGameplayAbilityActivationInfo ActivationInfo, const FGameplayEventData* TriggerEventData) override;

protected:

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	TSubclassOf<AActor> WeaponToSpawn;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	FName SocketName;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    FGameplayTag WeaponTag;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	bool bRegisterAsEquippedWeapon = true;
};
