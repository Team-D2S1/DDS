// Copyright © Team DDS 2025. Project DDS™ is a trademark of Team DDS. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "IDDSAbilitySystemInterface.generated.h"

class UDDSAbilitySystemComponent;
// This class does not need to be modified.
UINTERFACE(MinimalAPI)
class UIDDSAbilitySystemInterface : public UInterface
{
	GENERATED_BODY()
};

/**
 * 
 */
class DDS_API IIDDSAbilitySystemInterface
{
	GENERATED_BODY()

	// Add interface functions to this class. This is the class that will be inherited to implement this interface.
public:
	virtual UDDSAbilitySystemComponent* GetDDSAbilitySystemComponent() const = 0;
};
