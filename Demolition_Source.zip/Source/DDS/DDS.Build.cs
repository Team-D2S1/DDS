// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class DDS : ModuleRules
{
	public DDS(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
	
		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core", 
			"CoreUObject", 
			"Engine", 
			"NetCore",
			"InputCore", 
			"EnhancedInput", 
			"GameplayTags", 
			"GameplayTasks",
			"GameplayAbilities", 
			"UMG", 
			"Slate", 
			"SlateCore",
			"OnlineSubsystem",
			"OnlineSubsystemSteam",
			"Steamworks",
			"Sockets",
			"Networking",
			"Paper2D"
		});

		PrivateDependencyModuleNames.AddRange(new string[] {  });

		PublicIncludePaths.AddRange(new string[] { ModuleDirectory});
		// Uncomment if you are using Slate UI
		// PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });
		
		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");

		// To include OnlineSubsystemSteam, add it to the plugins section in your uproject file with the Enabled attribute set to true
	}
}
